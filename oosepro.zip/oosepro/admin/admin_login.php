<?php
// Start the session
session_start();

// Admin credentials
$admin_username = 'dhanu123';
$admin_password = 'dhanu@123';

// Retrieve form data
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Check if credentials match
if ($username === $admin_username && $password === $admin_password) {
    // Admin authenticated, redirect to admin homepage
    $_SESSION['admin_logged_in'] = true;
    header('Location: adminhome.html');
    exit;
} else {
    // Invalid credentials, redirect back to login page with error message
    header('Location: adminlogin.html?error=1');
    exit;
}
?>
