 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete request
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['student_name'])) {
    $student_name = $_GET['student_name'];
    $sql_delete = "DELETE FROM registration WHERE Student_name = ?";
    $stmt = $conn->prepare($sql_delete);
    $stmt->bind_param("s", $student_name);
    if ($stmt->execute()) {
        echo "Record deleted successfully.";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Handle edit request
if (isset($_POST['student_name']) && isset($_POST['new_name']) && isset($_POST['new_department']) && isset($_POST['new_course'])) {
    $student_name = $_POST['student_name'];
    $new_name = $_POST['new_name'];
    $new_department = $_POST['new_department'];
    $new_course = $_POST['new_course'];

    $sql_update = "UPDATE registration SET Student_name = ?, department = ?, course_name = ? WHERE Student_name = ?";
    $stmt = $conn->prepare($sql_update);
    $stmt->bind_param("ssss", $new_name, $new_department, $new_course, $student_name);
    if ($stmt->execute()) {
        echo "Record updated successfully.";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch student course information from the database
$sql = "SELECT Student_name, department, course_name FROM registration";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Course Information</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        /* Reset default margin and padding */
html, body {
    margin: 0;
    padding: 0;
}

/* Style for the container */
.container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Style for headings */
h2 {
    font-weight:bold;
    color: #333;
}

/* Style for the table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

/* Style for buttons */
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-top: 20px;
    cursor: pointer;
    border-radius: 8px;
    color : black;
    
}

/* Hover effect for buttons */
.button:hover {
    background-color: #45a049;
}

/* Active effect for buttons */
.button:active {
    background-color: #3e8e41;
}

    </style>
</head>
<body>
<div class="container">
<h2>Student Course Information</h2>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Course</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["Student_name"] . "</td>";
                echo "<td>" . $row["department"] . "</td>";
                echo "<td>" . $row["course_name"] . "</td>";
                echo "<td>";
                echo "<button class='edit-btn' onclick='editRow(\"" . $row['Student_name'] . "\", \"" . $row['department'] . "\", \"" . $row['course_name'] . "\")'>Edit</button>";
                echo "<a href='index.php?action=delete&student_name=" . $row['Student_name'] . "' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No student courses found</td></tr>";
        }
        ?>
    </tbody>
    </div>
</table>

<script>
function editRow(name, department, course) {
    var newName = prompt("Enter new name:", name);
    var newDepartment = prompt("Enter new department:", department);
    var newCourse = prompt("Enter new course:", course);

    if (newName && newDepartment && newCourse) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    location.reload(); // Refresh the page to reflect changes
                } else {
                    alert('Error updating record: ' + xhr.responseText);
                }
            }
        };
        xhr.open('POST', 'index.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send('student_name=' + name + '&new_name=' + newName + '&new_department=' + newDepartment + '&new_course=' + newCourse);
    }
}
</script>
 <button class="button" onclick="location.href='adminhome.html'">Go to Homepage</button>

</body>
</html>

<?php
// Close connection
$conn->close();
?>