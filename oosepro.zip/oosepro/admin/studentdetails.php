<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch student signup information from the database
$sql = "SELECT * FROM users1";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Signup Information</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 11px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        /* Reset default margin and padding */
html, body {
    margin: 0;
    padding: 0;
}

/* Style for the container */
.container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Style for headings */
h2 {
    color: #333;
}

/* Style for the table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

/* Style for buttons */
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-top: 20px;
    cursor: pointer;
    border-radius: 8px;
}

/* Hover effect for buttons */
.button:hover {
    background-color: #45a049;
}

/* Active effect for buttons */
.button:active {
    background-color: #3e8e41;
}

    </style>
</head>
<body>
    <div class="container">

<h2>Student Signup Information</h2>

<table>
    <thead>
        <tr>
            <th>Student Name</th>
            <th>Department</th>
            <th>Email</th>
            <th>username</th>
            <th>password</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["department"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["username"] . "</td>";
                echo "<td>" . $row["password"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No students found</td></tr>";
        }
        ?>
    </tbody>
</table>
 <button class="button" onclick="location.href='adminhome.html'">Go to Homepage</button>
    </div>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
